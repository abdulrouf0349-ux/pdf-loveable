import { createFileRoute, notFound } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { UploadCard } from "@/components/upload-card";
import { ToolsGrid } from "@/components/tools-grid";
import { HowTo, ApiBanner } from "@/components/marketing-sections";
import { toolBySlug } from "@/lib/tools";

export const Route = createFileRoute("/$tool")({
  loader: ({ params }) => {
    const tool = toolBySlug(params.tool);
    if (!tool) throw notFound();
    return { slug: tool.slug, name: tool.name, headline: tool.headline, description: tool.description };
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return {
        meta: [{ title: "Tool not found — Free PDF Convert" }, { name: "robots", content: "noindex" }],
      };
    }
    const title = `${loaderData.headline} — Free & Online`;
    return {
      meta: [
        { title },
        { name: "description", content: loaderData.description },
        { property: "og:title", content: title },
        { property: "og:description", content: loaderData.description },
      ],
    };
  },
  component: ToolPage,
});

function ToolPage() {
  const { slug } = Route.useLoaderData();
  const tool = toolBySlug(slug)!;

  return (
    <div className="min-h-screen bg-surface">
      <SiteHeader />
      <UploadCard
        title={tool.headline}
        subtitle={tool.description}
        icon={tool.icon}
        slug={tool.slug}
      />

      <HowTo />
      <div className="bg-surface">
        <ToolsGrid heading="Other PDF Tools" />
      </div>
      <ApiBanner />
      <SiteFooter />
    </div>
  );
}
